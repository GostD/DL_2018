from resnext.ResNext import ResNext
from resnext.Training import Training